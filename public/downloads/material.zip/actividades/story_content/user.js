function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5jm1CkqFOk6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

